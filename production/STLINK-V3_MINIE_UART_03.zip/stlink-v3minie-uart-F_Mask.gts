G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5-1-g226df246f3*
G04 #@! TF.CreationDate,2026-09-06T08:19:52+02:00*
G04 #@! TF.ProjectId,stlink-v3minie-uart,73746c69-6e6b-42d7-9633-6d696e69652d,03*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5-1-g226df246f3) date 2026-09-06 08:19:52*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.125000X-0.375000X-1.875000X0.375000X-1.875000X0.375000X1.875000X-0.375000X1.875000X0*%
%ADD11R,1.700000X1.700000*%
%ADD12C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X11000000Y2500000D03*
X9000000Y2500000D03*
X7000000Y2500000D03*
X5000000Y2500000D03*
X3000000Y2500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X1920000Y8250000D03*
D12*
X4460000Y8250000D03*
X7000000Y8250000D03*
X9540000Y8250000D03*
X12080000Y8250000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J3*
X3380000Y12500000D03*
D12*
X5920000Y12500000D03*
X8460000Y12500000D03*
X11000000Y12500000D03*
G04 #@! TD*
M02*
